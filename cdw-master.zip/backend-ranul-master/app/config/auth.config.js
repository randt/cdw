module.exports = {
  secret: "test-secret-key",
};
